<?php 

$host = '';  // the domain name .com without https://

$username = ''; //username of the email account

$emailpassword = ''; //password of the email account

$setForm = ''; //email that is mail is sending from (same as the username);

$send_to = ''; //email that is mail is sending to;


?>